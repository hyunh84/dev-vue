import 'vuetify/styles'
import '@/assets/css/vuetify.scss'

import { createVuetify } from 'vuetify'
import { aliases, mdi } from 'vuetify/iconsets/mdi-svg'

import * as components from 'vuetify/components'
import * as directives from 'vuetify/directives'

const themeH = {
	dark : false,
}

const vuetifyStyle = createVuetify(
	{
		theme : {
			defaultTheme : 'themeH',
			themes : {
				themeH
			}
		},
		icons : {
			defaultSet: 'mdi',
			sets: {
				mdi,
			},
			aliases : {
				...aliases,
			}
		}
	}
);

export default vuetifyStyle;