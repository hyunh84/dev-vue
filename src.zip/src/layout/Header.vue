<script setup>
	defineProps({
	showBackButton: Boolean,
	title: String,
	showLogoutButton: Boolean
	})
</script>

<template>
	<div class="header">
		Header Area
	</div>
</template>