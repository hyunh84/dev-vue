<template>
	<div class="guideTit">Button Guide page</div>

	<!-- <v-btn>Button</v-btn> -->
	<v-btn icon>Button</v-btn>
	<v-btn append-icon="$vuetify">Button</v-btn>
	<v-icon icon="mdiDomain"></v-icon>
	<!-- <v-btn prepend-icon="$vuetify">Button</v-btn>
	<v-btn prepend-icon="$vuetify" stacked>Button</v-btn> -->

	<v-icon icon="mdi-home" style="color: black; font-size: 40px;" />
    <v-btn icon>
      <v-icon icon="mdi-home" />
    </v-btn>
</template>