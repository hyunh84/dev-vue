<script setup>
	import './css/guide.scss';
	import Header from '@/layout/Header.vue';
</script>

<template>
	<v-app>
		<Header />
		<v-main class="guideLayout">
			<router-view />
		</v-main>
	</v-app>
</template>